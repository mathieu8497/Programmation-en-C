# Bibliothèques
* stdio.h
* stdlib.h
* time.h
* limits.h

# Références
* Aide apportée par le groupe de Maxime Balleur et Alice Esmilaire pour l'exercice recherche_dichotomique
* https://johnsamuel.info/fr/enseignement/cours/2023/C
* https://www.w3schools.com/c/c_pointers.php

# Difficulté
* Au debut du TP, difficulté pour prendre en main les structures et comprendre la commande random mais au final nous avons bien compris tous les éléments du TP.
* nous ne savons pas comment procéder à l'affichage des octets comme demandé dans l'exercice 3.6 (octets.c)

# Commentaires
* 
* 

