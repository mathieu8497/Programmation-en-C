# Bibliothèques
* stdio.h
* math.h

# Références
* https://johnsamuel.info/fr/enseignement/cours/2023/C
*

# Difficulté
* Aucune difficultés particulière pour ce premier TP. Nous avons pris un peu de temps pour prendre en main la programmation en C qui diffère un petit peu par rapport à Python mais après 4h de TP ça allait deja beaucoup mieux.

# Commentaires
*

