/*Nom du fichier : bonjour.c
Objectif : Affichage de "Bonjour le Monde" en C
Auteurs : Mathieu Poirel & Emma Tricquet */

#include <stdio.h>

int main(){
    printf("Bonjour le Monde!\n");
    return 0;
}