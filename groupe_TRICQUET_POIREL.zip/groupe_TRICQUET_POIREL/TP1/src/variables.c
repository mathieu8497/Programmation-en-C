// Nom du fichier : variables.c
// Objectif : Affecter et afficher des variables de types de base
// Auteurs : Mathieu Poirel & Emma Tricquet

#include <stdio.h>

int main(){
    char valeur = 18;
    printf("\nla valeur du char est %c\n",valeur);
    short valeur1 = 18;
    printf("\nla valeur du short est %hd\n",valeur1);
    int valeur2 = 18;
    printf("\nla valeur du int est %i\n",valeur2);
    long int valeur3 = 18;
    printf("\nla valeur du long int est %ld\n",valeur3);
    long long int valeur4 = 18;
    printf("\nla valeur du long long int est %lld\n",valeur4);
    float valeur5 = 18;
    printf("\nla valeur du float est %f\n",valeur5);
    double valeur6 = 18;
    printf("\nla valeur du double est %g\n",valeur6);
    long double valeur7 = 18;
    printf("\nla valeur du long double est %Lg\n",valeur7);
    return 0;
}