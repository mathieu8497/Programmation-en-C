# Bibliothèques
* stdio.h
* string.h

# Références
* https://johnsamuel.info/fr/enseignement/cours/2023/C
* https://www.w3schools.com/c/c_strings.php
* https://developpement-informatique.com/article/276/pointeurs-et-tableaux-en-langage-c
* https://www.w3schools.com/c/c_pointers_arrays.php
* https://openclassrooms.com/fr/courses/4117396-developpez-en-c-pour-lembarque/4633446-manipulez-les-registres-et-les-masques


# Difficulté
* Pas de difficultées notoires à part pour l'exercice 2.9 où nous avons eu des difficultés pour réaliser des tableaux en utilisant uniquement des pointeurs et pas de manipulation indicielles.

# Commentaires
* 

